using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Reporting.WebForms;
using System.Web;

namespace FuncRDLCtest
{
    public class Function1 : Controller
    {
        [FunctionName("Function1")]
        public static ActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log)
        {
            //log.Info("C# HTTP trigger function processed a request.");

            //// parse query parameter
            //string name = req.GetQueryNameValuePairs()
            //    .FirstOrDefault(q => string.Compare(q.Key, "name", true) == 0)
            //    .Value;

            //if (name == null)
            //{
            //    // Get request body
            //    dynamic data = await req.Content.ReadAsAsync<object>();
            //    name = data?.name;
            //}

            //return name == null
            //    ? req.CreateResponse(HttpStatusCode.BadRequest, "Please pass a name on the query string or in the request body")
            //    : req.CreateResponse(HttpStatusCode.OK, "Hello " + name);

            //Step 1 : Create a Local Report.
            LocalReport localReport = new LocalReport();

            //Step 2 : Specify Report Path.
            var binDirectory = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var rootDirectory = System.IO.Path.GetFullPath(System.IO.Path.Combine(binDirectory, "../../../../"));
            localReport.ReportPath = System.IO.Path.Combine(rootDirectory + "Reports\\Report1.rdlc");//Server.MapPath("~/Reports/RDLC/Report1.rdlc");


            //Step 3 : Create Report DataSources
            ReportDataSource dsUnAssignedLevels = new ReportDataSource();
            dsUnAssignedLevels.Name = "UnAssignedLevels";
            //dsUnAssignedLevels.Value = dataSet.UnAssignedLevels;

            ReportDataSource dsReportInfo = new ReportDataSource();
            dsReportInfo.Name = "ReportInfo";
            //dsReportInfo.Value = dataSet.ReportInfo;

            //Step 4 : Bind DataSources into Report
            localReport.DataSources.Add(dsUnAssignedLevels);
            localReport.DataSources.Add(dsReportInfo);

            //Step 5 : Call render method on local Report to generate report contents in Bytes array
            string deviceInfo = "<DeviceInfo>" +
             "  <OutputFormat>PDF</OutputFormat>" +
             "</DeviceInfo>";
            Warning[] warnings;
            string[] streams;
            string mimeType;
            byte[] renderedBytes;
            string encoding;
            string fileNameExtension;
            //Render the report          
            renderedBytes = localReport.Render("PDF", deviceInfo, out mimeType, out encoding, out fileNameExtension, out streams, out warnings);


            //Step 6 : Set Response header to pass filename that will be used while saving report.
            //Response.AddHeader("Content-Disposition", "attachment; filename=UnAssignedLevels.pdf");
            //check header and mime type

            //Step 7 : Return file content result
            var file = new FileContentResult(renderedBytes, mimeType);
            file.FileDownloadName = "downloadedRDLC";
            
            return file;
            
        }

        
    }
}
